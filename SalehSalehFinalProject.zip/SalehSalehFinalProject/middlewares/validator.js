const {body} = require('express-validator');
const {validationResult} = require('express-validator')


exports.validateId = (req, res, next) => {

    let id = req.params.id;

    if(!id.match(/^[0-9a-fA-F]{24}$/)) {
        let err = new Error('Invalid story id');
        err.status = 400;
        return next(err);

    } else {
        return next()
    }
};

exports.validateSignUp = [body('firstName', 'First name can not be empty').notEmpty().trim().escape(),
body('lastName', 'Last Name can not be empty').notEmpty().trim().escape(),
body('email', 'Email must be a valid email address').isEmail().trim().escape().normalizeEmail(),
body('password', 'password must be at least 8 characters and at most 64 characters long').isLength({min:8, max:64})];

exports.validateLogIn = [body('email', 'Email must be a valid email address').isEmail().trim().escape().normalizeEmail(),
body('password', 'password must be at least 8 characters and at most 64 characters long').isLength({min:8, max:64})];

exports.validateConnection = [body('connectionName', 'Connection Name should be at at least 3 characters').isLength({min:3}).notEmpty().trim().escape(),
body('connectionTopic', 'Connection Topic should be at least 3 characters').isLength({min:3}).notEmpty().trim().escape(),
body('details', 'details are required and they should be at least 10 characters').isLength({min:10}).notEmpty().trim().escape(),
body('date', 'Date should be new').notEmpty().isDate().isAfter(),
body('startTime', 'startTime is required').notEmpty().matches(/^(2[0-3]|[01]?[0-9]):([0-5]?[0-9])$/),
body('endTime', 'endTime is required').notEmpty().matches(/^(2[0-3]|[01]?[0-9]):([0-5]?[0-9])$/).custom((value, { req }) => {
    if (value < req.body.startTime) {
      throw new Error('End time should be greater');
    }
    
    return true;
  }),
];

exports.validateRSVP = [body('rsvp', 'Rsvp can only be Yes, No, or Maybe').isIn(['Yes', 'No', 'Maybe'])];


exports.validateResult = (req, res, next) => {
    let errors = validationResult(req);

    if(!errors.isEmpty()) {
        errors.array().forEach(error=> {
            req.flash('error', error.msg);
        });
        return res.redirect('back');
    } else {
        return next();
    }
}

