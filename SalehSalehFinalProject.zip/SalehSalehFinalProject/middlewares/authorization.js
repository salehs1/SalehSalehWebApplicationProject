const connection = require('../models/connection')

//checking to see if user is logged in
exports.userGuest = (req, res, next) => {
    if(!req.session.user) {
        return next();
    }

    else {
        req.flash('error', 'You are logged in already');
        return res.redirect('/user/profile')
    }
}

//check if user is authenticated
exports.isLoggedIn = (req, res, next) => {
    if(req.session.user) {
        return next();
    }

    else {
        req.flash('error', 'You need to login first');
        return res.redirect('/user/logIn')
    }
};

exports.isAuthor = (req, res, next) => {
    let id = req.params.id;

    connection.findById(id) 
    .then(Connection => {
        if(Connection) {
            if(Connection.hostName == req.session.user.id) {
                return next();
            } else {
                let err = new Error('Unauthorized to access resource');
                err.status = 401;
                return next(err)
            }
        } else {
            let err = new Error('Cannot find a connection with id ' + req.params.id);
            err.status = 404;
            return next(err);
        }
    })
    .catch(err=>next(err));
};

exports.isNotAuthor = (req, res, next) => {
    let id = req.params.id;

    connection.findById(id) 
    .then(Connection => {
        if(Connection) {
            if(Connection.hostName != req.session.user.id) {
                return next();
            } else {
                let err = new Error('Unauthorized to access resource');
                err.status = 401;
                return next(err)
            }
        }
    })
    .catch(err=>next(err));
}