
exports.index = (req, res) => {
    
    res.render('index');
};

exports.about = (req, res) => {
    res.render('./newView/about')
}

exports.contact = (req, res) => {
    res.render('./newView/contact')
}