const model = require('../models/connection')
const modelRSVP = require('../models/rsvp')
exports.index = (req, res, next) => {


model.find()

.then(connections => {
   
    
   model.distinct('connectionTopic')
  
  .then(topicCategories => {
 let categories = topicCategories
 console.log(categories)
    res.render('connections', {categories, connections})
  })
.catch(err=>next(err));

    
    
})
.catch(err=>next(err));
}
// POST Method for creating new connection
exports.new = (req, res) => {
    res.render('newConnection')

}

exports.create = (req, res, next) => {
    let connection = new model(req.body);
    connection.hostName = req.session.user.id;

    connection.save()
    
    .then(connection => {
        
      if(connection) {
        req.flash('success', 'You have successfully created a new connection');  
        res.redirect('/connections')
      }
    })
    .catch(err => {
        if (err.name ===  'ValidationError' ) {
            err.status = 400;
        }
        next(err);
    });
};

exports.show = (req, res, next) => {
    let id = req.params.id
    
    let user = req.session.user

    Promise.all([model.findById(id).populate('hostName', 'firstName' ), modelRSVP.find({connection:id, rsvp:"Yes"}) ])
    .then(results => {
        const [connection, userRSVP] = results
       if(connection) {
           console.log(userRSVP)
           return res.render('connection', {connection, userRSVP});
       }   
       else {
        let err = new Error('Cannot find a connection with id ' + id);
        err.status = 404;
        next(err);
       }
    })
    .catch(err=> next(err));
};

exports.edit = (req, res, next) => {
    let id = req.params.id
    

    model.findById(id)
    .then(connection => {

           console.log(connection)
           return res.render('./newView/edit', {connection});
       
    })
    .catch(err=> next(err));
    
    };

    exports.update = (req, res, next) => {
        let connection = req.body;
        let id = req.params.id;
    
    
        model.findByIdAndUpdate(id, connection, {useFindAndModify: false, runValidators: true})
        .then(connection => {
                req.flash('success', 'You have successfully updated the connection');
                res.redirect('/connections/'+ id);
        
        })
        .catch(err => {
            if(err.name === 'ValidationError')
               err.status = 400;
            next(err)
        });
    
    };

    exports.createRSVP = (req, res, next) => {
        let rsvp = req.body.rsvp;

        let id = req.params.id;

        let user = req.session.user.id;

        let userRSVP = {
            connection: id,
            rsvp: req.body.rsvp,
            user: req.session.user.id
        };
    
            modelRSVP.findOneAndUpdate({connection:id, user:user}, userRSVP,  {useFindAndModify: false, runValidators: true, upsert: true, new:true} )
               .then(rsvp=>{
                req.flash('success', 'rsvp is successfully created');
                res.redirect('/user/profile');
            })
            .catch(err=>{
                
                if(err.name === 'validationError') {
                    req.flash('error', err.message);
                    return res.redirect('/back');
                }
                next(err);
            });
            
        }


    exports.delete = (req, res, next) => {
        let id = req.params.id;
        
        Promise.all([model.findByIdAndDelete(id, {useFindAndModify: false}),  modelRSVP.deleteMany({connection:id})])
        .then(connection => {
           if(connection) {
                res.redirect('/connections');
           } else {
            let err = new Error("Cannot find the connection with id " + id);
            err.status = 404;
            next(err);
           }
        })
        .catch(err=> next(err));
    };





