
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const connectionSchema = new Schema({
    connectionName: {type: String, required: [true, 'connectionName is required']},
    connectionTopic: {type: String, required: [true, 'connectionTopic is required']},
    details: {type: String, required: [true, 'details are required'],
              minLength: [10, 'the details should have at least 10 characters']},
    date: {type: String, required: [true, 'date is required']},
    startTime: {type: String, required: [true, 'startTime is required']},
    endTime: {type: String, required: [true, 'endTime is required']},
    hostName: {type: Schema.Types.ObjectId, ref: 'User'},
    location: {type: String, required: [true, 'location is required']},
    image: {type: String, required: [true, 'imageURL is required']},
    
  },
  {timestamps: true}
  )
  
module.exports = mongoose.model('Connection', connectionSchema);



