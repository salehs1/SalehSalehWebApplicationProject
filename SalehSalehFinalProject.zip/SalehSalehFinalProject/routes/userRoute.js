const express = require('express');
const controller = require('../controllers/userController');
const {userGuest} = require('../middlewares/authorization')
const {isLoggedIn} = require('../middlewares/authorization');
const {validateSignUp, validateLogIn, validateResult} = require("../middlewares/validator");

const {logInLimiter} = require('../middlewares/rateLimiters');
const router = express.Router();

//GET: send the html form for creating user account
router.get('/signUp', userGuest,   controller.new);

//POST: create a new user account
router.post('/', userGuest, validateSignUp, validateResult, controller.create)

//GET: send html for logging in
router.get('/logIn',  userGuest,  controller.getUserLogin);

//POST: authenticate user's login
router.post('/logIn',  logInLimiter, userGuest, validateLogIn,  validateResult, controller.login);


//GET: send user's profile page
router.get('/profile', isLoggedIn, controller.profile);



//POST /users/logout: logout a user
router.get('/logOut', isLoggedIn, controller.logout)

module.exports = router;