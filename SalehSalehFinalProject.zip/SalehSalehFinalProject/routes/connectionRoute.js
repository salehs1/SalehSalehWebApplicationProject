const express = require('express');
const connectionRouter = express.Router();
const controller = require('../controllers/connectionController');

const {isLoggedIn, isAuthor, isNotAuthor} = require('../middlewares/authorization');
const { validateId, validateRSVP, validateResult, validateConnection } = require('../middlewares/validator');

//GET /stories: send all stories to the user

connectionRouter.get('/', controller.index)

//GET /stories/new: send html form for creating new story

connectionRouter.get('/new', isLoggedIn,  controller.new)


//POST /stories: creating a new story
connectionRouter.post('/', isLoggedIn, validateConnection, validateResult, controller.create)


//GET /stories/:id :send details of the story identified by id
 connectionRouter.get('/:id', validateId, controller.show)


//GET /stories/:id/edit :send html form for editing an existing story
connectionRouter.get('/:id/edit', validateId, isLoggedIn, isAuthor, controller.edit)


//PUT /stories/:id : identify the story identified by id
connectionRouter.put('/:id', validateId, isLoggedIn, isAuthor, validateConnection, validateResult, controller.update)

//POST: create an RSVP
connectionRouter.post('/:id/rsvp', validateId, isLoggedIn, isNotAuthor, validateRSVP, validateResult, controller.createRSVP)



//DELETE /stories/:id, delete the story identified by id
connectionRouter.delete('/:id', validateId, isLoggedIn, isAuthor, controller.delete)
module.exports = connectionRouter;




































