const express = require('express');
const mainRouter = express.Router();

const controller = require('../controllers/mainController');


mainRouter.get('/', controller.index) 

mainRouter.get('/about', controller.about)

mainRouter.get('/contact', controller.contact)

module.exports = mainRouter;